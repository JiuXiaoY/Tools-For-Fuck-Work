from __future__ import annotations

import os
import unittest
from decimal import Decimal
from unittest.mock import patch

from openpyxl import Workbook

from config import Config
from core import PipelineContext, PipelineStep
from core.runner import Pipeline
from preprocess.steps.rebuild import rebuild_sheet
from rules.price import extract_price_before_jpy
from services.utils import is_blank, round_decimal, to_decimal
from steps.fill_id import FillIdStep, default_id_factory


class ConfigTests(unittest.TestCase):
    def test_secret_is_loaded_from_environment(self) -> None:
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": "local-test-key"}):
            self.assertEqual(Config().ai_api_key, "local-test-key")

    def test_custom_id_factory_is_used(self) -> None:
        config = Config(id_factory=lambda _date: "fixed-id")
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.append(["a"])
        worksheet.append(["b"])
        context = PipelineContext(workbook=workbook, worksheet=worksheet)
        FillIdStep(config).run(context)
        self.assertEqual(worksheet.cell(1, config.col_b).value, "fixed-id")
        self.assertEqual(worksheet.cell(2, config.col_b).value, "fixed-id")


class UtilityTests(unittest.TestCase):
    def test_decimal_helpers(self) -> None:
        self.assertEqual(to_decimal("12.345"), Decimal("12.345"))
        self.assertIsNone(to_decimal("not-a-number"))
        self.assertEqual(round_decimal(Decimal("1.235")), 1.24)

    def test_blank_detection(self) -> None:
        self.assertTrue(is_blank(None))
        self.assertTrue(is_blank("  "))
        self.assertFalse(is_blank(0))

    def test_price_before_jpy(self) -> None:
        text = "19.99 EUR 22.10 USD 2482.25 JPY"
        self.assertEqual(extract_price_before_jpy(text), Decimal("22.10"))

    def test_default_id_shape(self) -> None:
        generated = default_id_factory("260708")
        self.assertEqual(len(generated), 16)
        self.assertEqual(generated[6:12], "bfzgzh")


class PipelineTests(unittest.TestCase):
    def test_dependency_validation_rejects_missing_step(self) -> None:
        class Dependent(PipelineStep):
            name = "dependent"
            requires = ("base",)

            def run(self, context: PipelineContext) -> PipelineContext:
                return context

        with self.assertRaisesRegex(ValueError, "must follow"):
            Pipeline([Dependent()])

    def test_continue_on_error_records_failure(self) -> None:
        class Broken(PipelineStep):
            name = "broken"

            def run(self, context: PipelineContext) -> PipelineContext:
                raise ValueError("bad row")

        workbook = Workbook()
        context = PipelineContext(workbook=workbook, worksheet=workbook.active)
        result = Pipeline([Broken()], continue_on_error=True).run(context)
        self.assertEqual(result.metadata["failed_steps"][0]["step"], "broken")


class RebuildTests(unittest.TestCase):
    def test_rebuild_keeps_selected_rows_and_sheet_position(self) -> None:
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = "Data"
        worksheet.append(["keep-1"])
        worksheet.append(["drop"])
        worksheet.append(["keep-2"])
        rebuilt = rebuild_sheet(
            workbook,
            worksheet,
            lambda row: row != 2,
        )
        self.assertEqual(rebuilt.title, "Data")
        self.assertEqual([rebuilt.cell(row, 1).value for row in (1, 2)], ["keep-1", "keep-2"])
        self.assertEqual(workbook.sheetnames, ["Data"])


if __name__ == "__main__":
    unittest.main()
