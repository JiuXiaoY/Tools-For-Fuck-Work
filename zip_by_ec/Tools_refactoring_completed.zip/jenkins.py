"""Jenkins pipeline — full automation from .xls to optimized output.

Steps:
  1. xls → xlsx          (tools/xls2xlsx.py)
  2. Preprocess           (preprocess/run.py)
  3. Excel pipeline       (main.py: merge + 13-step pipeline)
  4. Color re-processing  (tools/color_size_deal/color_reprocess.py)
  5. Title optimization   (tools/title_optimize/title_rewrite.py)
  6. Title auto fill      (tools/title_auto_fill/de_title_build.py)
  7. Export SKU            (tools/export_sku/export_sku.py)

Usage:
    python jenkins.py
"""

from __future__ import annotations

from importlib import import_module
from openpyxl import load_workbook
from pathlib import Path

from services.logger import get_logger
from config import Config
from core import PipelineContext
from core.runner import process_context
from preprocess.run import preprocess_context

BASE = Path(__file__).resolve().parent
_log = get_logger("jenkins")

STEPS: list[tuple[str, str]] = [
    # ("xls → xlsx", "tools.xls2xlsx"),
    # ("Preprocess", "preprocess.run"),
    # ("Excel pipeline", "main"),
    # ("Color re-processing", "tools.color_size_deal.color_reprocess"),
    ("Title optimization", "tools.title_optimize.title_rewrite"),
    # ("de title build", "tools.title_auto_fill.de_title_build"),
    # ("Export SKU", "tools.export_sku.export_sku"),
]


def run_excel_in_memory(xlsx_path: Path, config: Config | None = None) -> PipelineContext:
    """Preprocess and transform one workbook with a single load/save cycle."""
    config = config or Config()
    workbook = load_workbook(xlsx_path)
    try:
        context = PipelineContext(
            workbook=workbook,
            worksheet=workbook.active,
            source_path=xlsx_path,
            source_filename=xlsx_path.name,
        )
        preprocess_context(context, config)
        process_context(context, config, checkpoint_source=xlsx_path)
        workbook.save(xlsx_path)
        return context
    finally:
        workbook.close()


def main() -> None:
    _log.info("=" * 50)
    _log.info("Jenkins pipeline — %d steps", len(STEPS))
    _log.info("=" * 50)

    for i, (name, module_name) in enumerate(STEPS, 1):
        _log.info("")
        _log.info("[%d/%d] %s", i, len(STEPS), name)
        _log.info("-" * 30)

        try:
            module = import_module(module_name)
            module.main()
        except Exception:
            _log.exception("[%d/%d] %s FAILED", i, len(STEPS), name)
            _log.error("Pipeline aborted.")
            raise
        _log.info("[%d/%d] %s OK", i, len(STEPS), name)

    _log.info("")
    _log.info("=" * 50)
    _log.info("All %d steps completed successfully", len(STEPS))

    # ── Clean up generated intermediary files ──
    for f in [
        BASE / "tools" / "title_optimize" / "optimize_title",
        BASE / "tools" / "title_optimize" / "origin_link",
        BASE / "tools" / "title_optimize" / "origin_title",
        BASE / "tools" / "color_size_deal" / "check_.txt",
    ]:
        try:
            f.write_text("", encoding="utf-8")
            _log.info("Cleared: %s", f.relative_to(BASE))
        except Exception as exc:
            _log.warning("Failed to clear %s: %s", f.relative_to(BASE), exc)


if __name__ == "__main__":
    main()
