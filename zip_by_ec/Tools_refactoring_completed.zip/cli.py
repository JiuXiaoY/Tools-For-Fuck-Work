"""Unified command-line entry point for the Excel processing toolkit."""

from __future__ import annotations

import argparse
from importlib import import_module
from pathlib import Path

from openpyxl import load_workbook

from config import Config
from core import PipelineContext
from core.runner import Pipeline
from services.excel import save

TOOLS = {
    "color": "tools.color_size_deal.color_reprocess",
    "title": "tools.title_optimize.title_rewrite",
    "keywords": "tools.needToCollect.hotwords",
    "images": "tools.image_classification.reorder",
    "export-sku": "tools.export_sku.export_sku",
}


def _step_prefix(specification: str, config: Config):
    from steps import get_steps

    steps = get_steps(config)
    if not specification:
        return steps
    try:
        start_text, end_text = specification.split("-", 1)
        start, end = int(start_text), int(end_text)
    except (ValueError, TypeError) as exc:
        raise ValueError("--steps must use START-END, for example 1-5") from exc
    if start != 1 or end < start or end > len(steps):
        raise ValueError(f"--steps must be a dependency-safe prefix from 1 to {len(steps)}")
    return steps[:end]


def _run_pipeline(input_path: Path | None, step_spec: str) -> None:
    if input_path is None and not step_spec:
        import main
        main.main()
        return
    if input_path is None:
        raise ValueError("--input is required when --steps is used")

    config = Config()
    workbook = load_workbook(input_path)
    try:
        context = PipelineContext(
            workbook=workbook,
            worksheet=workbook.active,
            source_path=input_path,
            source_filename=input_path.name,
        )
        Pipeline(
            _step_prefix(step_spec, config),
            continue_on_error=config.pipeline_continue_on_error,
        ).run(context)
        save(workbook, input_path)
    finally:
        workbook.close()


def _run_preprocess(input_path: Path | None) -> None:
    if input_path is None:
        from preprocess.run import main
        main()
        return
    from preprocess.run import preprocess_context

    config = Config()
    workbook = load_workbook(input_path)
    try:
        context = PipelineContext(
            workbook=workbook,
            worksheet=workbook.active,
            source_path=input_path,
            source_filename=input_path.name,
        )
        preprocess_context(context, config)
        workbook.save(input_path)
    finally:
        workbook.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="dealexcel")
    commands = parser.add_subparsers(dest="command", required=True)

    pipeline = commands.add_parser("pipeline", help="Run the main Excel pipeline")
    pipeline.add_argument("--input", type=Path)
    pipeline.add_argument("--steps", default="", help="Dependency-safe prefix, e.g. 1-5")

    preprocess = commands.add_parser("preprocess", help="Run source preprocessing")
    preprocess.add_argument("--input", type=Path)

    commands.add_parser("run-all", help="Run the configured orchestration")
    tool = commands.add_parser("tool", help="Run a standalone utility")
    tool.add_argument("name", choices=sorted(TOOLS))
    return parser


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    if args.command == "pipeline":
        _run_pipeline(args.input, args.steps)
    elif args.command == "preprocess":
        _run_preprocess(args.input)
    elif args.command == "run-all":
        import jenkins
        jenkins.main()
    elif args.command == "tool":
        import_module(TOOLS[args.name]).main()


if __name__ == "__main__":
    main()
