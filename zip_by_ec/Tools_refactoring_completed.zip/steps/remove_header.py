﻿"""Remove header rows: if row-1 col-1 has no fill color, delete the row and shift images up."""

from core import PipelineContext, PipelineStep
from services import cell_has_fill, shift_image_anchor


class RemoveHeaderStep(PipelineStep):
    name = "delete_header"
    description = "Remove header rows from all sheets based on fill color"

    def run(self, ctx: PipelineContext) -> PipelineContext:
        removed = 0
        for name in ctx.workbook.sheetnames:
            ws = ctx.workbook[name]
            if ws.max_row == 0:
                continue
            if cell_has_fill(ws.cell(row=1, column=1)):
                ctx.log(f"Sheet [{name}]: row 1 has fill, skip")
            else:
                ws.delete_rows(1)
                # openpyxl delete_rows does NOT shift image anchors — fix them
                for img in ws._images:
                    img.anchor = shift_image_anchor(img.anchor, -1, minimum_row=0)
                removed += 1
                ctx.log(f"Sheet [{name}]: header row removed, images adjusted")
        if removed == 0:
            ctx.log("All sheets: row 1 has fill, no header to remove")
        ctx.worksheet = ctx.workbook.active
        return ctx
