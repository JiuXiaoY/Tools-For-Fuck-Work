"""Generate German product titles for marker rows in the current output workbook."""

from __future__ import annotations

import sys
import time
from datetime import datetime
from pathlib import Path

import openpyxl

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from config import Config
from services import cell_has_fill
from services.ai_client import AIClient
from services.logger import get_logger

BASE = Path(__file__).resolve().parent
FINAL_TITLES = BASE / "final_de_title"
_log = get_logger("de_collect")

SYSTEM_PROMPT = """Du bist ein erfahrener E-Commerce-Texter. Übersetze den
chinesischen Produkttitel in einen präzisen deutschen Produkttitel. Bewahre
alle objektiven Produktmerkmale, erfinde keine Eigenschaften und gib nur den
fertigen deutschen Titel ohne Erklärung aus."""


def _resolve_date(config: Config) -> str:
    raw = config.date_override.strip()
    if raw and len(raw) == 6:
        try:
            return f"{int(raw[2:4])}.{int(raw[4:6])}"
        except ValueError:
            pass
    today = datetime.now()
    return f"{today.month}.{today.day}"


def _load_source_titles(source: Path) -> list[str]:
    workbook = openpyxl.load_workbook(source, read_only=True)
    try:
        worksheet = workbook.active
        titles: list[str] = []
        for row in range(1, worksheet.max_row + 1):
            if not cell_has_fill(worksheet.cell(row=row, column=1)):
                continue
            value = worksheet.cell(row=row, column=8).value
            if value is None or not str(value).strip():
                raise ValueError(f"Row {row}: source title in column H is empty")
            titles.append(str(value).strip())
        return titles
    finally:
        workbook.close()


def main() -> None:
    config = Config()
    source = Path(__file__).resolve().parent.parent.parent / config.out_dir / (
        f"{_resolve_date(config)}v1.xlsx"
    )
    if not source.exists():
        _log.error("Source not found: %s", source)
        return
    if not config.ai_api_key:
        _log.error("Set DEEPSEEK_API_KEY before generating German titles")
        return

    titles = _load_source_titles(source)
    if not titles:
        _log.error("No marker-row titles found in %s", source.name)
        return
    client = AIClient.get(config.ai_provider, config.ai_api_key, config.ai_model)

    translated: list[str] = []
    for index, title in enumerate(titles, 1):
        for attempt in range(1, config.retry_max_rounds_deepseek + 1):
            try:
                result = client.chat_with_text(title, SYSTEM_PROMPT).strip()
                if not result:
                    raise ValueError("AI returned an empty title")
                translated.append(result)
                _log.info("[%d/%d] translated", index, len(titles))
                break
            except Exception as exc:
                if attempt >= config.retry_max_rounds_deepseek:
                    raise RuntimeError(f"Title {index} failed after retries") from exc
                _log.warning("[%d/%d] retry %d: %s", index, len(titles), attempt, exc)
                time.sleep(config.delays.retry_pause)
        if index < len(titles):
            time.sleep(config.delays.ui_action)

    FINAL_TITLES.write_text("\n".join(translated), encoding="utf-8")
    _log.info("Generated %d German titles: %s", len(translated), FINAL_TITLES.name)


if __name__ == "__main__":
    main()
