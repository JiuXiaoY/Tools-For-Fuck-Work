"""Compatibility entry point for the former duplicate image reorder script.

The maintained implementation lives in :mod:`tools.image_classification.reorder`.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from tools.image_classification.reorder import main

__all__ = ["main"]


if __name__ == "__main__":
    main()
