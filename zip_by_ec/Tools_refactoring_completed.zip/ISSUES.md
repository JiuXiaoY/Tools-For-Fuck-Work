# dealExcel_refactoring 问题清单

> 按优先级排序:P0=安全/致命, P1=架构/严重影响维护, P2=可维护性改善, P3=优化建议。
> 每个问题标注文件:行号,先不改动,仅记录。

---

## 🔴 P0 — 安全/致命

### 1. API 密钥硬编码在仓库中 **[已修复]**
- **文件**:`config.py:70`
- **内容**:`ai_api_key: str = "sk-39b17cf2e6a542508090bb1c8d07570d"` — 真实的 DeepSeek API 密钥
- **影响**:密钥已提交到版本控制,通过 git history 可被任何人获取。需立即轮换密钥并迁移到环境变量
- **对比**:`config.example.py:70` 正确使用了空字符串
- **修复**:`config.py` 改为从 `DEEPSEEK_API_KEY` 环境变量读取，仓库不再保存密钥；按任务要求不处理外部账号轮换。

---

## 🟠 P1 — 架构/严重影响维护

### 2. Config 注入形同虚设 — 11 处重复 `Config()` **[已修复]**
- **涉及文件**:所有 `steps/*.py`(除 `finalize.py` 外 11 个步骤文件)
- **问题**:`core/runner.py:19` 接受 `Config` 参数传给 pipeline,但每个 `PipelineStep.run()` 内部都自己调 `Config()` 重新实例化,外部传入的配置**被完全忽略**
- **影响**:
  - 无法测试(无法注入 mock 配置)
  - 无法在单进程用不同配置处理不同文件
  - 步骤的依赖不透明(看代码不知道配置从哪来)
- **根因**:`PipelineStep` 没有 `__init__` 接收 Config
- **修复**:`PipelineStep` 统一持有可注入的 `Config`，`get_steps(config)` 将同一实例传给全部步骤；保留无参构造兼容性。

### 3. 两套步骤接口并存,互不兼容 **[已修复]**
- **核心 Pipeline**:`PipelineStep.run(ctx: PipelineContext) → PipelineContext`(`core/pipeline.py:15`)
- **预处理步骤**:`self.run(wb: Workbook, path: str) → int`(`preprocess/steps/dedup_filled_rows.py:30`)
- **问题**:同样的"步骤"概念,签名完全不同。预处理步骤不是 `PipelineStep` 子类,无法被核心 pipeline 调度,也无法共享日志/上下文机制
- **影响**:增加认知负担,两套注册表要分别维护
- **修复**:三个预处理步骤统一继承 `PipelineStep` 并使用 `PipelineContext`，预处理入口复用核心 `Pipeline` 调度与日志机制。

### 4. openpyxl 工作簿泄露 — `wb.close()` 缺失 **[已修复]**
- **`core/runner.py:21-32`**:`process_file()` → `load_workbook()` → 只 `save()` 不 `close()`
- **`services/excel.py:47`**:`merge_workbooks()` 打开源文件后不关闭
- **`services/excel.py:21-23`**:`save()` 不对 workbook 调用 `close()`
- **`main.py:69-70`**:`merge_workbooks()` + `save()` 后的 workbook 未关闭
- **正面例子**:`preprocess/run.py:40-44` 正确调用了 `save()` → `close()`
- **影响**:42MB 的 xlsx 文件不关闭,长期运行会累积内存/文件句柄
- **修复**:`process_file()`、`save()` 和多文件合并路径均使用 `finally` 关闭工作簿；合并失败时也会释放目标工作簿。

### 5. 三个 `except Exception: pass` 静默吞异常 **[已修复]**
- **`services/excel.py:75-76`**:合并单元格失败 → `pass`,不输出任何警告
- **`steps/merge_sheets.py:85-86`**:同上
- **`services/utils.py:47-48`**:`to_decimal()` 捕获所有异常返回 `None` — 其中包括 `KeyboardInterrupt` 和 `SystemExit`
- **`rules/price.py:21-22`**:`extract_price_before_jpy()` 同样问题
- **影响**:数据静默丢失不可追踪;`KeyboardInterrupt` 可能被吞掉导致进程无法退出
- **修复**:合并单元格失败记录明确警告；数值转换只捕获预期的格式/类型异常，不再吞掉进程控制异常。

### 6. "重建 sheet"逻辑重复 × 3 — 代码量最大 **[已修复]**
- **文件**:`preprocess/steps/remove_header.py:56-104`、`dedup_filled_rows.py:77-166`、`remove_empty_j.py:44-131`
- **问题**:三段代码的模板完全一致:创建临时 sheet → 复制行(值+样式+图片+合并单元格+列宽) → 替换旧 sheet。唯一差异是"哪些行要删"的判定规则
- **影响**:约 200 行重复代码;修改复制逻辑(如增加一列样式属性)需要改三个地方
- **建议抽象**:`rebuild_sheet(ws, keep_predicate: Callable[[int], bool]) → Worksheet`
- **修复**:新增共享 `rebuild_sheet()`，统一复制值、样式、行高、图片、合并单元格和列宽；三个预处理步骤只保留各自的删行规则。

### 7. `jenkins.py` 用 `subprocess.run` 串步骤 — 多余进程边界 **[已修复]**
- **文件**:`jenkins.py:43-56`
- **问题**:每步都是一个独立 Python 子进程,通信全靠文件系统;当前 7 步中 5 步注释掉
- **影响**:
  - 步骤失败时只能看到"子进程返回非零",无堆栈
  - 每次子进程启动都要重新 import 全部模块
  - 无法在内存中传递中间状态
- **这些步骤完全可以改成进程内函数调用**
- **修复**:步骤表改为模块路径，运行时惰性导入并直接调用各模块 `main()`；异常保留完整堆栈并中止流水线。

---

## 🟡 P2 — 可维护性

### 8. `config.example.py` 与 `config.py` 不同步 **[已修复]**
- **缺失字段**:`img_classify_mode`、`img_classify_ocr_lang`、`img_classify_table_min_lines`
- **默认值不一致**(5 处):`date_override`("260708" vs "260731")、`price_add`("6.00" vs "1.50")、`delete_source_after_merge`(True vs False)、`preprocess_dedup_close_gap`(10 vs 5)、`ai_api_key`(真实密钥 vs "")
- **节标题不同**:`image classification` vs `image reorder`
- **影响**:新用户按 example 模板创建 config 后,缺少 3 个配置字段会导致 AttributeError
- **修复**:示例配置已同步全部字段、默认值、章节名称和环境变量密钥加载方式。

### 9. `constant/` 目录 — 未使用的杂项数据,疑似敏感信息 **[已修复]**
- **文件**:`constant/dzq` 包含邮箱、品牌名、验证码等数据
- **状态**:无任何 Python 代码 import `constant/` 目录
- **`constant/photo/`**:4 个参考 PNG 图片,无代码引用
- **修复**:`constant/photo/`、`constant/dzq` 已加入 `.gitignore` 并从 git 跟踪移除

### 10. ID 生成逻辑硬编码 — 无扩展性 **[已修复]**
- **文件**:`steps/fill_id.py:10-29`
- **硬编码内容**:
  - 编码表:base62(`string.digits + ascii_uppercase + ascii_lowercase`)
  - 分段格式:`6 位前缀 + 6 位日期码 + 4 位后缀`(固定 16 字符)
  - 日期编码:`0→z, 1→a, ..., 9→i`
- **影响**:不同平台需要不同 ID 格式时,只能复制整个函数重写
- **建议**:做成可注入的 `Callable` 参数,当前不需要完整类层次
- **修复**:新增可选 `Config.id_factory` 注入点，默认工厂保持原 base62 与日期编码格式不变。

### 11. 价格计算公式硬编码 **[已修复]**
- **文件**:`steps/calc_price.py:27-30`
- **硬编码**:四步链 `AS=base, AT=base×1.2, AU=AT-7.98, AV=AU+1.50` — 乘数/减数/加数虽来自 config,但**步骤数量和顺序**写死在代码里
- **影响**:不同市场(含 VAT / 不含 VAT)需要不同计算链时无法配置
- **建议**:与 ID 生成同理,做成可注入的函数或公式字符串
- **修复**:新增 `Config.price_calculator` 可调用注入点；默认计算器保留原 AS→AV 公式和逐步舍入语义。

### 12. 29 处 `time.sleep()` 硬编码 **[已修复]**
- **涉及文件**:`tools/title_optimize/run.py`(3 处模块常量)、`deepseek_web.py`(14 处硬编码)、`hotwords.py`(`REQUEST_INTERVAL=2.0`+ 2 处 0.5/3)、`hotwords_fashion.py`(`REQUEST_INTERVAL=2.0`+ 硬编码 3)、`image_classification/reorder*.py`(3 处 1s)
- **影响**:API 限流策略调整(如 amz123 改成 1s/次)需要改代码
- **config.py 现状**:有 `retry_max_rounds_*`,但无 `delay_*` 或 `interval_*`
- **修复**:新增集中式 `DelayConfig`，API、网页自动化、重试和图片下载的所有等待时间均从配置读取。

### 13. `RemoveEmptyJStep` — 完整实现但注释掉 **[已修复]**
- **文件**:`preprocess/steps/remove_empty_j.py:1-147`(147 行完整实现)
- **注册**:`preprocess/steps/__init__.py:4,11` 两处注释掉
- **状态**:无其他引用,可能是死代码,也可能是未完工的功能
- **影响**:147 行代码占位但未使用
- **修复**:加入 `preprocess_remove_empty_j` 配置开关并接入预处理注册表，默认关闭以保持原行为，需要时可直接启用。

### 14. 图片 anchor 行号操作重复 × 2(以上) **[已修复]**
- **核心流程**`merge_sheets.py` 和**预处理 3 个步骤**各自手写:
  ```python
  if isinstance(anchor, OneCellAnchor):
      old_row = anchor._from.row + 1
  elif isinstance(anchor, TwoCellAnchor):
      old_row = anchor._from.row + 1
  ```
- **`services/images.py`** 有 `snapshot_images` / `restore_images`,但没有封装"提取行号/平移 anchor"的通用函数
- **影响**:每次用到 anchor 都要重复判断;`services/excel.py:75`(merge_workbooks 内)也有一份
- **修复**:`services.images` 新增统一的 `image_anchor_row()` 与 `shift_image_anchor()`，预处理和表头步骤复用同一实现。

### 15. `services/excel.py` 使用 `logging.getLogger` 绕过项目日志系统 **[已修复]**
- **文件**:`services/excel.py:14`
- **问题**:项目统一用 `services/logger.py:get_logger()`,但 excel.py 直接用 stdlib `logging.getLogger(__name__)`,多个 handler/格式不一致
- **修复**:`services.excel` 改用统一的 `get_logger("excel")`。

### 16. 无步骤级容错 — 部分失败即全部丢失 **[已修复]**
- **文件**:`core/runner.py:46-56`
- **问题**:Pipeline 12 步串行,没有任何 try/except 包裹单步;如果第 11 步失败,前 10 步的更改无法保存(workbook 只在所有步骤跑完后 save)
- **影响**:调试困难(无法查看失败时的中间状态);无法只重跑失败步骤
- **修复**:`Pipeline` 捕获并记录具体失败步骤，默认抛出带步骤名的异常；可通过 `pipeline_continue_on_error` 选择记录失败后继续。

### 17. 无中间检查点 **[已修复]**
- 关联 #16:如果 Pipeline 支持"每完成 N 步存一个中间文件"或"保存 Context 到临时路径",长流程调试效率会高得多
- **修复**:新增 `pipeline_checkpoint_every`，启用后按步骤间隔保存带步骤名的 `.checkpoints/*.xlsx` 并记录到 Context 元数据。

### 18. 多层数据传递全靠文件系统 **[已修复]**
- **链路**:preprocess 写回源文件 → main 读源文件合并 → tools 读输出文件再加工再写回
- **问题**:每次 read/write openpyxl 都重新解析 42MB 的 xlsx;1000 行不明显,10 万行时是显著瓶颈
- **中间零内存传递**
- **修复**:预处理与主流水线均提供 `PipelineContext` 内存入口，`run_excel_in_memory()` 可在一次加载/保存周期内串联两层处理；文件只作为工作流边界。

### 19. `tools/image_classification/reorder_backup.py` — `reorder.py` 的 ~90% 重复副本 **[已修复]**
- **文件**:`reorder.py` 和 `reorder_backup.py` 高度相似
- **影响**:改一处不同步另一处,逐渐分化
- **修复**:`reorder_backup.py` 保留为兼容入口并委托唯一维护的 `reorder.main()`，不再复制实现。

### 20. `MergeSheetsStep` 未使用 `services/images.py` 的图片辅助 **[已修复]**
- **文件**:`steps/merge_sheets.py:54-84` 内联了图片复制的全部逻辑
- **问题**:`services/images.py` 有 `clone_image`,但 merge_sheets 自己的图片循环没用到,自己写了一份
- **修复**:`MergeSheetsStep` 直接调用 `clone_image(..., row_offset=...)`，移除内联锚点复制逻辑。

### 21. `services/images.py:58` — `restore_images` 依赖整个 Config 对象 **[已修复]**
- **文件**:`services/images.py:58`
- **问题**:`restore_images` 只需要 `column_insertions: list[tuple[int,int]]`,却接收整个 `Config`,耦合了不必要的数据结构
- **修复**:`restore_images()` 仅接收 `column_insertions`，调用方显式传入所需字段。

### 22. 配置加载无缓存 — `load_color_mapping` / `load_size_mapping` 每次读磁盘 **[已修复]**
- **文件**:`config.py:106-120`
- **问题**:`FillCol10MappingStep` 和 `SizeMappingStep` 各自调用时都会重新 open+parse JSON
- **影响**:742 条 color_mapping.json + size_mapping.json 每次管道运行读 2 次磁盘
- **修复**:两个映射在 `Config` 实例内惰性加载并缓存，后续调用直接复用内存字典。

### 23. `tools/title_auto_fill/de_title_build.py:4` — TODO 标记未闭环 **[已修复]**
- **内容**:`# de_collect.py — populate final_de_title (TODO)`
- **影响**:自动化步骤不完整
- **修复**:`de_collect.py` 已实现：读取输出表标记行标题、调用已配置 AI 翻译为德语、重试并写入 `final_de_title`。

### 24. 热词采集 fashion_brands.txt 首行追加丢失 bug(已修复但原因不明) **[已修复]**
- **文件**:`tools/needToCollect/fashion_filter/fashion_brands.txt`
- **问题**:bash heredoc 追加时 `geox` 首行丢失,原因未知(可能 Windows 换行符问题)
- **已修复**:通过 Python 工具 edit_file 补回
- **影响**:说明基于 bash heredoc 的文件追加在 Windows 下不可靠

---

## 🟢 P3 — 小改进

### 25. `deepseek_web.py` 的选择器硬编码 **[已修复]**
- **问题**:`button:has-text('Stop')`、`"div.ds-assistant-message-main-content"` 等 CSS 选择器与 DeepSeek UI 版本绑定
- **影响**:DeepSeek 页面改版后需手动同步选择器;无版本兼容机制
- **修复**:新增 `DeepSeekSelectors` 配置，消息、停止按钮、输入框、上传和模式按钮选择器全部集中管理。

### 26. 项目日志系统仅一处不一致 **[已修复]**
- **文件**:`services/excel.py:14` 用 `logging.getLogger(__name__)` 而非 `get_logger("excel")`
- **影响**:细微不一致,Excel 模块日志可能丢失项目级的格式/级别配置
- **修复**:与 #15 为同一问题，`services.excel` 已统一使用项目日志器。

### 27. `services/logger.py:26-27` — 模块级全局状态 **[已修复]**
- **内容**:`_log_file: Path | None = None`, `_initialized: bool = False`
- **影响**:正式单线程使用无问题,但多人协作或多线程时会成为隐式竞争
- **修复**:日志初始化状态封装到 `_LoggingState`，并以可重入锁保护一次性 handler 初始化和日志路径发布。

### 28. `core/pipeline.py` — Pipeline 无步骤排序/依赖验证 **[已修复]**
- **问题**:12 步的注册靠 `get_steps()` 里的硬编码列表顺序,每步间有隐式数据依赖(如 InsertColumns 必须先于列引用)但未声明
- **影响**:加新步骤时容易放错位置
- **修复**:`PipelineStep.requires` 声明前置步骤，`Pipeline` 构造时校验重复名称、缺失依赖和错误顺序。

### 29. 缺少统一的 CLI 入口 **[已修复]**
- **现状**:`main.py` 无参数、`preprocess/run.py` 无参数、`jenkins.py` 硬编码步骤、各 tools 各有一套 argparse
- **影响**:用户需记住多个入口点,无法 `dealexcel pipeline --steps 1-5`
- **修复**:新增 `cli.py`，统一提供 `pipeline`、`preprocess`、`run-all` 和 `tool` 子命令，并支持依赖安全的 `--steps 1-N`。

### 30. 缺少测试 **[已修复]**
- **状态**:整个项目无任何 test_*.py 文件
- **影响**:重构和修改配置逻辑时无安全网;商业化接客户前需手工回归
- **修复**:新增标准库 `unittest` 测试，覆盖配置注入、ID、价格与数值规则、步骤依赖/容错和工作表重建。

### 31. 缺少类型检查 CI **[已修复]**
- **现状**:有 `from __future__ import annotations` + 类型注解,但无 `mypy`/`pyright` 配置和 CI 检查
- **影响**:类型注解失去约束力,实际运行时可能类型不匹配
- **修复**:新增 `pyproject.toml` 的 mypy 规则和 GitHub Actions CI，自动执行编译、单元测试与类型检查。

### 32. `main.py` 异常处理把临时文件删除和重新抛混在一起 **[已修复]**
- **文件**:`main.py:83-86`
- **问题**:`except Exception as exc: tmp.unlink(missing_ok=True); raise` — `KeyboardInterrupt` 等非 Exception 异常不会被此 except 捕获(try/except Exception),但 `SystemExit` 会?不会。逻辑正确性没问题,但意图不明确(是只处理预期错误还是兜底?)
- **修复**:抽出 `_remove_partial_output()`，明确任何中止（含用户中断）均删除未完成输出、记录原因并原样重新抛出。

### 33. `.gitignore` 缺 `constant/photo/` 和 `constant/dzq` **[已修复]**
- **修复**:`constant/photo/`、`constant/dzq` 已加入 `.gitignore`,`constant/photo/` 下 4 个 PNG 和 `constant/dzq` 已从 git 跟踪移除(`git rm --cached`)

### 34. `fashion_filter` 的弱属性 `wolle` 有历史重复(强属性段 `!wolle` 残留) **[已修复]**
- **已修复**:`fashion_attributes.txt:17` 的 `!wolle` 已删除
- **教训**:同一词在强/弱两段各出现一次,copy-paste error 的典型案例

### 35. 三个预处理步骤的输出目录不同 **[已修复]**
- `remove_header` 输出 `_rm_header_tmp` 临时 sheet
- `dedup_filled_rows` 输出 `_dedup_tmp`
- `remove_empty_j` 输出 `_rm_empty_j_tmp`
- **问题**:命名不统一,如果多个临时 sheet 同时存在时会冲突(实际先 remove 再 create,不冲突,但可读性差)
- **修复**:共享重建器统一使用 `_preprocess_tmp` 临时工作表名，各步骤不再自定义名称。

### 36. 热词单关键词模式调用参数缺失 **[已修复]**
- **文件**:`tools/needToCollect/hotwords.py`
- **问题**:`--single` 分支调用 `extract_words(raw)`，但函数要求 `sort_mode` 与 `cfg`，运行时会抛出 `TypeError`。
- **修复**:单关键词模式显式传入 `new_rank` 模式和当前配置实例。

---

## 统计

| 优先级 | 数量 | 未修复 |
|---|---|---|
| 🔴 P0 | 1 | 0 |
| 🟠 P1 | 6 | 0 |
| 🟡 P2 | 17 | 0 |
| 🟢 P3 | 12 | 0 |
| **合计** | **36** | **0** |

> 已修复全部 36 项；本轮完成原有 31 个未修复项，并在全面扫描中补充修复 #36，每项均有独立提交。
